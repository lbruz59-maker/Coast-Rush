Coast Rush V27.9 - projet Android paysage

Cette archive contient la structure Android correcte.
Pour compiler depuis GitHub sans Android Studio :
1. Televerser cette archive ZIP dans le depot GitHub.
2. Ajouter le workflow .github/workflows/build.yml (instructions dans la conversation).
3. Lancer Actions > Build Coast Rush Phone APK > Run workflow.
4. Recuperer l'APK dans Artifacts.

L'archive seule ne declenche pas la compilation. Le workflow doit d'abord etre ajoute au depot.
