COAST RUSH V32 - VERSION WEB HTTPS

Le jeu est contenu dans index.html. Aucun serveur applicatif ni installation
n'est nécessaire : le site peut être publié comme site statique.

PUBLICATION SIMPLE AVEC GITHUB PAGES (HTTPS)
1. Ouvre le dépôt GitHub du jeu.
2. Envoie index.html et ce README à la racine du dépôt (remplace l'ancienne
   version de index.html).
3. Dans Settings > Pages, choisis "Deploy from a branch", puis la branche
   main et le dossier /(root), et enregistre.
4. GitHub Pages publie le jeu sur une adresse HTTPS. Le certificat HTTPS est
   géré automatiquement par GitHub Pages ; aucun logo Netlify n'est ajouté.

MULTIJOUEUR
Le multijoueur utilise WebRTC pour les échanges entre joueurs et des relais
MQTT sécurisés en WSS pour la signalisation. Il nécessite une adresse HTTPS
publique dans les navigateurs qui imposent un contexte sécurisé.

MODIFICATIONS V32
- Neige : adhérence rétablie pour rendre la conduite contrôlable.
- Neige : bonus de 10 % au temps conservé au départ et aux étapes suivantes.
- Chase H.Q. : pas de compte à rebours avant la poursuite, y compris après
  l'attente multijoueur.
- Chase H.Q. : bandit placé à 50 m au premier niveau, puis 16 m plus loin
  à chaque niveau suivant.
- Cinématique d'arrestation : uniforme et casquette de policier plus lisibles.

Compatibilité : site web mobile/ordinateur, avec HTTPS requis pour les
fonctions navigateur sensibles et le multijoueur.
